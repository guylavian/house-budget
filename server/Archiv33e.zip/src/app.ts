import 'dotenv/config';
// eslint-disable-next-line @typescript-eslint/no-require-imports
require('log-node')();
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import log from './lib/logger';

import salaryRoutes from './routes/salary';
import expensesRoutes from './routes/expenses';
import houseRoutes from './routes/house';
import savingsRoutes from './routes/savings';
import dashboardRoutes from './routes/dashboard';
import exportRoutes from './routes/export';
import configRouter from './routes/config';
import bankRouter from './routes/bank';

import { connectMongo } from './lib/mongo';
import { classificationService } from './services/classificationService';
import { errorHandler } from './middleware/errorHandler';

const app = express();
const PORT = process.env.PORT ?? 3001;

app.use(cors({ origin: 'http://localhost:5173', credentials: true }));
app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.use('/api/salary', salaryRoutes);
app.use('/api/expenses', expensesRoutes);
app.use('/api/house', houseRoutes);
app.use('/api/savings', savingsRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/export', exportRoutes);
app.use('/api/config', configRouter);
app.use('/api/bank', bankRouter);

app.use((_req, res) => {
  res.status(404).json({ error: 'Not found' });
});

app.use(errorHandler);

async function bootstrap(): Promise<void> {
  await connectMongo();
  await classificationService.initialize();
  app.listen(PORT, () => {
    log.notice('Server running on http://localhost:%s', PORT);
  });
}

bootstrap().catch((err) => log.error(err));

export default app;
